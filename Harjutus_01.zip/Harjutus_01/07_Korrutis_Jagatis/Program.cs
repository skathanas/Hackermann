﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Korrutis_Jagatis
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mina olen kalkulaatori programm. Ütle mulle 2 numbrit ja ma ütlen Sulle nende korrutise ja jagatise \n");

            Console.Write("Palun sisesta esimene number: ");
            string input1 = Console.ReadLine();
            int sisestatudNumber1 = int.Parse(input1);

            Console.Write("Palun sisesta teine number: ");
            string input2 = Console.ReadLine();
            int sisestatudNumber2 = int.Parse(input2);

            Console.WriteLine();
            Console.WriteLine("korrutades " + input1 + " ja " + input2 + " on tulemuseks " + (sisestatudNumber1 * sisestatudNumber2));
            Console.WriteLine($"Jagades {sisestatudNumber1} ja {sisestatudNumber2} on tulemuseks: {sisestatudNumber1 / sisestatudNumber2}\n");
            // Console.WriteLine("jagades " + input1 + " ja " + input2 + " on tulemuseks " + (sisestatudNumber1 / sisestatudNumber2) + "\n");
            Console.WriteLine("Pressi anikiid");
            Console.ReadLine();
        }
    }
}
