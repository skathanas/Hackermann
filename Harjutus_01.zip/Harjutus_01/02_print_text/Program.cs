﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_print_text
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tere");
            Console.WriteLine(); ///tühi rida
            Console.WriteLine("Minu nimi on (sisesta oma nimi) ning õping esimest korda programmeerima!");
            Console.WriteLine(); ///tühi rida (võimalik ka \n)
            Console.WriteLine("Kindlasti on võimalik midagi rohkemat, kui lihtsalt teksti printimine \n");
            Console.WriteLine("Press any key to continue");
            Console.ReadLine();
        }
    }
}
