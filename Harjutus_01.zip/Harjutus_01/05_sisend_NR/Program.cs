﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_sisend_NR
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hei! Kaks numbrit");
            
            Console.Write("Palun sisesta number: ");
            string input = Console.ReadLine();

            int sisestatudNumber = int.Parse(input);

            int number = 5;

            Console.WriteLine(number + sisestatudNumber);

            Console.ReadLine();
        }
    }
}
