﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_IF
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("sisesta number: ");

            string input = Console.ReadLine();
            int Number1 = int.Parse(input);
                

            int Number2 = 5;

            if (Number2 < Number1) {
                Console.WriteLine("Number on suurem");
            }
            
            if (Number2 > Number1)
            {
                Console.WriteLine("Number on väiksem");
            }

            if (Number2 == Number1)
            {
                Console.WriteLine("Number on 5");
            }

            Console.WriteLine("pressi enikiid \n");
            Console.ReadLine();

        }



    }
    }

