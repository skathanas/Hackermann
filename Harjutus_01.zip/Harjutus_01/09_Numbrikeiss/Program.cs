﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09_Numbrikeiss
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("sisesta number: ");

            string input = Console.ReadLine();
            int Number1 = int.Parse(input);


            int Number2 = 5;

            bool hasNotGuessed = true;
            while (hasNotGuessed)
            { 
                if (Number2 < Number1)
            {
                Console.WriteLine("Number on suurem");
                    hasNotGuessed = false;
            }

            if (Number2 > Number1)
            {
                Console.WriteLine("Number on väiksem");
                    hasNotGuessed = false;
                }

            if (Number2 == Number1)
            {
                Console.WriteLine("Number on 5");
                    hasNotGuessed = true;
                }
            }

            Console.WriteLine("pressi enikiid \n");

            Console.ReadLine();
        }
    }
}
